import { Document, Paragraph, Table } from 'docx';
import {
    buildFooter,
    buildHeader,
    makeareaBox,
    areaHeading,
    noveltyDetail,
    noveltyTitle,
    thinSeparator,
} from './blocks';
import { imageGallery, type ImgEscalada } from './blocks/imageGallery';
import {
    loadImageOriginal,
    insertarOrdenado,
    comparaImagenesPorAltoAncho,
    type ImagenOrdenada,
} from './images';

interface FlatItem {
    sectorGeneral: string;
    areaNovedad: string;
    tituloNovedad: string;
    detalleNovedad: string;
    imagenesNovedad?: string[];
}

interface BuildDocInput {
    novedades: FlatItem[];
}

async function buildSectionsAsync(
    sections: {
        areaNovedad: string;
        items: {
            tituloNovedad: string;
            detalleNovedad: string;
            imagenesNovedad?: string[];
        }[];
    }[],
    pageContentWidthPx: number,
    minImageWidthPx = 0
): Promise<Paragraph[]> {
    const out: Paragraph[] = [];

    for (const { areaNovedad, items } of sections) {
        out.push(areaHeading(areaNovedad));

        for (const {
            tituloNovedad,
            detalleNovedad,
            imagenesNovedad,
        } of items) {
            out.push(noveltyTitle(tituloNovedad));
            const detalleParas = noveltyDetail(detalleNovedad);
            out.push(...detalleParas);

            if (imagenesNovedad && imagenesNovedad.length > 0) {
                const wrappersOrdenados: ImagenOrdenada[] = [];

                for (const url of imagenesNovedad) {
                    try {
                        const raw = await loadImageOriginal(url);
                        if (!raw) continue;

                        const relacion =
                            raw.ancho > 0 ? raw.alto / raw.ancho : 0;
                        if (!(relacion > 0 && isFinite(relacion))) continue;

                        const naturalMax = Math.min(
                            Math.max(1, raw.ancho),
                            Math.max(1, pageContentWidthPx)
                        );

                        const width =
                            minImageWidthPx > 0
                                ? Math.min(
                                      naturalMax,
                                      Math.max(1, minImageWidthPx)
                                  )
                                : naturalMax;

                        const height = Math.max(
                            1,
                            Math.round(width * relacion)
                        );

                        const wrapper: ImagenOrdenada = {
                            data: raw.data,
                            dimension: { alto: height, ancho: width },
                            dimensionOriginal: {
                                alto: raw.alto,
                                ancho: raw.ancho,
                            },
                            extension: raw.extension,
                        };

                        insertarOrdenado(
                            wrappersOrdenados,
                            wrapper,
                            comparaImagenesPorAltoAncho
                        );
                    } catch {
                        // Imagen fallida, continuar sin agregar
                    }
                }

                if (wrappersOrdenados.length > 0) {
                    const escaladas: ImgEscalada[] = wrappersOrdenados.map(
                        (w) => ({
                            data: w.data,
                            width: w.dimension.ancho,
                            height: w.dimension.alto,
                            extension: w.extension,
                        })
                    );

                    const galleryParas = imageGallery(escaladas);
                    out.push(...galleryParas);
                }
            }

            out.push(thinSeparator());
        }

        out.push(new Paragraph({ spacing: { after: 50 } }));
    }

    return out;
}

export async function createNovedadesDoc(
    input: BuildDocInput
): Promise<Document> {
    const PAGE_CONTENT_WIDTH = 500;
    const MIN_IMAGE_WIDTH = 0;

    // 1. Agrupar por sectorGeneral
    const groupedBySector: Record<string, FlatItem[]> = {};
    for (const nov of input.novedades) {
        if (!groupedBySector[nov.sectorGeneral]) {
            groupedBySector[nov.sectorGeneral] = [];
        }
        groupedBySector[nov.sectorGeneral].push(nov);
    }

    // ✅ Aceptar tanto Paragraph como Table
    const allChildren: (Paragraph | Table)[] = [];

    // 2. Procesar cada sectorGeneral
    for (const [sectorGeneral, itemsFlat] of Object.entries(groupedBySector)) {
        allChildren.push(makeareaBox(sectorGeneral)); // Esto es un Table

        // 3. Agrupar por areaNovedad
        const areaMap: Record<string, FlatItem[]> = {};
        for (const item of itemsFlat) {
            if (!areaMap[item.areaNovedad]) {
                areaMap[item.areaNovedad] = [];
            }
            areaMap[item.areaNovedad].push(item);
        }

        const secciones = Object.entries(areaMap).map(
            ([areaNovedad, items]) => ({
                areaNovedad,
                items: items.map(
                    ({ tituloNovedad, detalleNovedad, imagenesNovedad }) => ({
                        tituloNovedad,
                        detalleNovedad,
                        imagenesNovedad,
                    })
                ),
            })
        );

        const paragraphs = await buildSectionsAsync(
            secciones,
            PAGE_CONTENT_WIDTH,
            MIN_IMAGE_WIDTH
        );
        allChildren.push(...paragraphs);
    }

    return new Document({
        styles: {
            default: {
                document: {
                    run: { font: 'Calibri' },
                    paragraph: { spacing: { before: 80, after: 80 } },
                },
            },
        },
        sections: [
            {
                headers: { default: buildHeader('YPF-Confidencial') },
                footers: { default: buildFooter('YPF-Confidencial') },
                children: allChildren,
            },
        ],
    });
}

export default createNovedadesDoc;
