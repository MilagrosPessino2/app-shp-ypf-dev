
require("./NovedadesPage.module.css");
const styles = {
  page: 'page_96f2258d',
  header: 'header_96f2258d',
  headerInner: 'headerInner_96f2258d',
  brand: 'brand_96f2258d',
  logo: 'logo_96f2258d',
  appName: 'appName_96f2258d',
  actions: 'actions_96f2258d',
  main: 'main_96f2258d',
  card: 'card_96f2258d',
  title: 'title_96f2258d',
  subtitle: 'subtitle_96f2258d',
  ctaRow: 'ctaRow_96f2258d',
  footer: 'footer_96f2258d'
};

export default styles;
