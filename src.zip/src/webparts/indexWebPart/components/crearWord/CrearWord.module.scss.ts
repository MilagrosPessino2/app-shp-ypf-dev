
require("./CrearWord.module.css");
const styles = {
  button: 'button_8c521cc9'
};

export default styles;
