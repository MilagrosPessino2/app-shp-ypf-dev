export declare const Roles: {
    ADMINISTRADORES: string;
    OTRO: string;
};
export declare const DOCX_FILENAME = "Novedades_YPF.docx";
export declare const COLOR_TOKENS: {
    readonly bordeArea: "2F5597";
    readonly fondoArea: "D9E2F3";
    readonly tituloItemNovedad: "153D63";
    readonly textoDetalleNovedad: "141414";
    readonly separadorLinea: "000000";
    readonly textoNegro: "000000";
};
export declare const TAMANIO: {
    tamanioTittle: number;
    tamanioTextoDetalleNovedad: number;
    tamanioTextoFooterHeader: number;
    tamanioBorderArea: number;
    tamanioTextoArea: number;
};
//# sourceMappingURL=Constants.d.ts.map