import { Document } from 'docx';
/**
 * Empaqueta un Document a .docx y lo descarga automáticamente.
 * Usa file-saver y NO abre el blob en otra pestaña (evita doble descarga).
 */
export declare function downloadDoc(doc: Document, filename?: string): Promise<void>;
//# sourceMappingURL=downloadDoc.d.ts.map