/**
 * Tipo mínimo requerido para poder calcular área.
 */
export type Dimension = {
    width: number;
    height: number;
};
/**
 * Comparator: ordena por área ASC.
 * - Si el área es igual, ordena por alto ASC.
 * - Si también es igual, ordena por ancho ASC.
 */
export declare function compareByArea(a: Dimension, b: Dimension): number;
//# sourceMappingURL=compareArea.d.ts.map