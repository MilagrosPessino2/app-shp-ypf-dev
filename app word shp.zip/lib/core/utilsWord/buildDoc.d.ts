import { Document } from 'docx';
import type { BuildDocInput } from './types';
export declare function createNovedadesDoc(input: BuildDocInput): Promise<Document>;
export default createNovedadesDoc;
//# sourceMappingURL=buildDoc.d.ts.map