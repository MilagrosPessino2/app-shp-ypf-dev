export type DimensionHW = {
    alto: number;
    ancho: number;
};
export type ImagenOrdenada = {
    data: ArrayBuffer;
    dimension: DimensionHW;
    dimensionOriginal: {
        alto: number;
        ancho: number;
    };
    extension: 'image/png';
};
/** Descarga + convierte a PNG seguro; devuelve bytes + dimensiones */
export declare function loadImageOriginal(url: string): Promise<{
    data: ArrayBuffer;
    alto: number;
    ancho: number;
    extension: 'image/png';
} | null>;
export declare function comparaImagenesPorAltoAncho(a: ImagenOrdenada, b: ImagenOrdenada): number;
export declare function insertarOrdenado<T>(coleccion: T[], aInsertar: T, comparar: (a: T, b: T) => number): T[];
//# sourceMappingURL=images.d.ts.map