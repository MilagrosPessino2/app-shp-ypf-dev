import { Paragraph } from 'docx';
export declare function htmlToParagraphsControlled(html: string): Paragraph[];
//# sourceMappingURL=htmlToDoc.d.ts.map