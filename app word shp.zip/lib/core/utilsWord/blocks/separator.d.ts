import { Paragraph } from 'docx';
/** Línea separadora fina entre items */
export declare function thinSeparator(): Paragraph;
//# sourceMappingURL=separator.d.ts.map