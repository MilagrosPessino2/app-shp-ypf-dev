import { Paragraph } from 'docx';
/** Encabezado del área (ej. "POWER APPS") */
export declare function areaHeading(text: string): Paragraph;
//# sourceMappingURL=areaHeading.d.ts.map