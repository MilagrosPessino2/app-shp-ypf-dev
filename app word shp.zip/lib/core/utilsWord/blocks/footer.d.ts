import { Footer } from 'docx';
/** Footer reutilizable (centrado) */
export declare function buildFooter(label: string): Footer;
//# sourceMappingURL=footer.d.ts.map