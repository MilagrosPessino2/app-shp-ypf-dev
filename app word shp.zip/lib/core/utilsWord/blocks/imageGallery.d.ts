import { Paragraph } from 'docx';
export type ImgEscalada = {
    data: ArrayBuffer;
    width: number;
    height: number;
    extension?: 'image/png' | 'image/jpeg';
};
export declare function imageGallery(images: ImgEscalada[]): Paragraph[];
//# sourceMappingURL=imageGallery.d.ts.map