import { Header } from 'docx';
/** Header reutilizable (texto a la derecha) */
export declare function buildHeader(label: string): Header;
//# sourceMappingURL=header.d.ts.map