import { Paragraph } from 'docx';
export declare function noveltyDetail(htmlFragment: string): Paragraph[];
//# sourceMappingURL=noveltyDetail.d.ts.map