import { Table } from 'docx';
/** Franja "area" con fondo y borde del sector */
export declare function makeareaBox(sectorGeneral: string): Table;
//# sourceMappingURL=areaBox.d.ts.map