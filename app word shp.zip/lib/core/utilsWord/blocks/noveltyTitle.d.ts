import { Paragraph } from 'docx';
/** Título de novedad (ítem) */
export declare function noveltyTitle(text: string): Paragraph;
//# sourceMappingURL=noveltyTitle.d.ts.map