import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export interface IIndexWebPartProps {
}
export default class IndexWebPart extends BaseClientSideWebPart<IIndexWebPartProps> {
    render(): void;
    protected onDispose(): void;
}
//# sourceMappingURL=IndexWebPart.d.ts.map