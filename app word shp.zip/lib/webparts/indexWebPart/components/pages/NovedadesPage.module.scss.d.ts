declare const styles: {
    page: string;
    header: string;
    headerInner: string;
    brand: string;
    logo: string;
    appName: string;
    actions: string;
    main: string;
    card: string;
    title: string;
    subtitle: string;
    ctaRow: string;
    footer: string;
};
export default styles;
//# sourceMappingURL=NovedadesPage.module.scss.d.ts.map