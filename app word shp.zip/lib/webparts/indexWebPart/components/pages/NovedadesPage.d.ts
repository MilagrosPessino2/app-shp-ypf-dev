import * as React from 'react';
import { WebPartContext } from '@microsoft/sp-webpart-base';
type Props = {
    context: WebPartContext;
};
declare const NovedadesPages: React.FC<Props>;
export default NovedadesPages;
//# sourceMappingURL=NovedadesPage.d.ts.map