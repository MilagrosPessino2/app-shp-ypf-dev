import { WebPartContext } from '@microsoft/sp-webpart-base';
/** Columnas (internal names = display names) según tu captura */
export type ListaPruebaFields = {
    SectorGeneral?: string;
    AreaNovedad?: string;
    TituloNovedad?: string;
    DetalleNovedad?: string;
    Resumen?: string;
    Title?: string;
};
export type NovedadItem = {
    tituloNovedad: string;
    detalleNovedad: string;
    imagenesNovedad: string[];
};
export type NovedadesData = {
    area: string;
    novedad: Array<{
        areaNovedad: string;
        items: NovedadItem[];
    }>;
};
export declare class GraphListService {
    private context;
    private client;
    private siteId;
    constructor(context: WebPartContext);
    init(): Promise<void>;
    /** Trae y mapea: agrupa por AreaNovedad y define SectorGeneral (más frecuente) */
    fetchNovedades(listDisplayName: string): Promise<NovedadesData>;
    private buildGraphSiteId;
    private getList;
    private getItems;
    private pickMostFrequent;
}
//# sourceMappingURL=listaConGraph.d.ts.map