declare const styles: {
    button: string;
};
export default styles;
//# sourceMappingURL=CrearWord.module.scss.d.ts.map