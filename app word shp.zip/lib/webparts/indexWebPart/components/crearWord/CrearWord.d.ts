import * as React from 'react';
import { WebPartContext } from '@microsoft/sp-webpart-base';
type Props = {
    context: WebPartContext;
};
declare const CrearWord: React.FC<Props>;
export default CrearWord;
//# sourceMappingURL=CrearWord.d.ts.map