import { BuildDocInput } from '../../../../core/utilsWord/types';
import { WebPartContext } from '@microsoft/sp-webpart-base';
type UseNovedadesArgs = {
    context: WebPartContext;
    filename?: string;
    listName?: string;
    /** Si pasás esto, NO consulta Graph y usa este input tal cual */
    inputOverride?: Omit<BuildDocInput, 'maxItemsPerSection'>;
};
export declare function useNovedades({ context, filename, listName, inputOverride, }: UseNovedadesArgs): {
    handleDownload: () => Promise<void>;
    loading: boolean;
};
export {};
//# sourceMappingURL=useNovedadesDownload.d.ts.map