import * as React from "react";
interface ProtectedRouteProps {
    requiredRole: string;
    children: React.ReactNode;
    userGroups: string[];
}
declare const ProtectedRoute: React.FC<ProtectedRouteProps>;
export default ProtectedRoute;
//# sourceMappingURL=ProtectedRoute.d.ts.map