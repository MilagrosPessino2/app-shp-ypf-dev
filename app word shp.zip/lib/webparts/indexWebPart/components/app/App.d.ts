import * as React from "react";
import { WebPartContext } from "@microsoft/sp-webpart-base";
interface IAppProps {
    context: WebPartContext;
}
declare const App: React.FC<IAppProps>;
export default App;
//# sourceMappingURL=App.d.ts.map