import * as React from "react";
declare const Forbidden: React.FC;
export default Forbidden;
//# sourceMappingURL=Forbidden.d.ts.map