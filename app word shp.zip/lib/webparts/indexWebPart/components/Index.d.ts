import * as React from "react";
import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IIndexProps {
    context: WebPartContext;
}
declare const Index: React.FC<IIndexProps>;
export default Index;
//# sourceMappingURL=Index.d.ts.map